console.log("loadstate reached");
var loadState={

	preload: function(){
		var loadingLabel= game.add.text(80,150,'Loading...',{font: '30px Courier',fill: '#ffffff'});


				game.load.image('sky', 'assets/sky.png');
				//game.load.image('ground', 'assets/platform.png');
				//game.load.image('ground', 'assets/platform2.png');
				game.load.image('ground', 'assets/floorblock.png');
				game.load.image('star', 'assets/star.png');
				//game.load.spritesheet('dude', 'assets/dude.png', 32, 48);

				game.load.spritesheet('dude', 'assets/Fighter1master.png', 36, 42);
				game.load.spritesheet('chick', 'assets/Fighter2master.png', 36, 42);

				game.load.image('hitboxTest', 'assets/testHitbox.png');
				game.load.spritesheet('baddie', 'assets/baddie.png', 32, 32 );
				game.load.spritesheet('slash', 'assets/slash (1).png', 64, 64 );
				game.load.spritesheet('slash2', 'assets/slash.png', 32, 32 );
				game.load.spritesheet('helmet', 'assets/helmet.png', 32, 32 );
				game.load.spritesheet('bottle', 'assets/bottle.png', 32, 32 );
				game.load.spritesheet('book', 'assets/book.png', 32, 32 );
				game.load.spritesheet('Sandbag', 'assets/sandbag.png', 32, 32 );
		},
	create: function(){
		game.state.start('menu');

	}
};
