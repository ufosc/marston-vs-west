console.log("playstate reached");

var playState={

  hit: function()
  {
    Player2.health=Player2.health-5;
  },

  //fighter class
  Fighter: function(character,health,lives,startx,starty,controlnum)
      {

      this.character = game.add.sprite(startx, starty, character);//player character variable to access sprite from phaser and all its properties character variable is name of spritesheet to use
      this.health = health;//player start health
      this.lives = lives;

      //Respawn Animation Activator Switch
      this.respawnSwitch = false;
      //m is the respawn animation counter
      this.m = 0;

      this.startx = startx;
      this.starty = starty;

      this.controlnum = controlnum;

      this.state = 0; //player state for state machine?

      this.jumps = 0;

      this.character.anchor.setTo(0.5,0);

          //  We need to enable physics on the player
      game.physics.arcade.enable(this.character);

      //  Player physics properties. Give the little guy a slight bounce.
      this.character.body.bounce.y = 0;//0.2;
      this.character.body.gravity.y = 400;
      this.character.body.collideWorldBounds = false;
    this.character.body.setSize(20, 42, 10, 0)

      this.character.animations.add('right', [2, 3, 0], 10, true);

      //idle animation
      this.character.animations.add('idle', [0, 1], 5, true);

      //jump animation
      this.character.animations.add('jump', [8, 9], 5, true); //need to adjust animation speed

      //shield animation
      this.character.animations.add('shield', [7], 5, true);

      //punch animations
      this.character.animations.add('punch', [5], 5, true);

      //kick
      this.character.animations.add('kick', [6], 5, true);

      //player got hit animation
      this.character.animations.add('ko', [7], 5, true);


      this.character.scale.x = 2;
      this.character.scale.y = 2;

      //this.controller1 = game.input.keyboard.addKeys({ 'up': Phaser.KeyCode.W, 'down': Phaser.KeyCode.S, 'left': Phaser.KeyCode.A, 'right': Phaser.KeyCode.D , 'punch': Phaser.KeyCode.T, 'kick': Phaser.KeyCode.R});

      if(controlnum == 1)
      {
      this.controller1 = new Object;
      controller1 = game.input.keyboard.addKeys({ 'up': Phaser.KeyCode.W, 'down': Phaser.KeyCode.S, 'left': Phaser.KeyCode.A, 'right': Phaser.KeyCode.D , 'punch': Phaser.KeyCode.T, 'kick': Phaser.KeyCode.R});
    }
    else if(controlnum == 2)
    {
    this.controller2 = new Object;
    controller2 = game.input.keyboard.addKeys({ 'up': Phaser.KeyCode.UP, 'down': Phaser.KeyCode.DOWN, 'left': Phaser.KeyCode.LEFT, 'right': Phaser.KeyCode.RIGHT , 'punch': Phaser.KeyCode.P, 'kick': Phaser.KeyCode.O});
    }

      /*Weapon Creation
      if (controlnum == 2){
          this.weapon1 = game.add.weapon(1, 'slash');
          weapon1.bulletKillType = Phaser.Weapon.KILL_LIFESPAN;
          weapon1.bulletLifespan = 50;
          weapon1.bulletSpeed = 0;
          weapon1.fireRate = 1;
          weapon1.trackSprite(character, 28, 50, true);
      }*/

      this.weapon1 = game.add.weapon(1, 'slash');
      this.weapon1.bulletKillType = Phaser.Weapon.KILL_LIFESPAN;
      this.weapon1.bulletLifespan = 50; //50
      this.weapon1.bulletSpeed = 0; //0
      this.weapon1.fireRate = 100;
      this.weapon1.trackSprite(this.character, 28, 40, true);
      return this;
    },



  updateInput: function(controller,Fighter,cooldownNum)
  {
      if (controller.left.isDown && !(Fighter.m < 120 && Fighter.m != 0))
      {
          //  Move to the left

          if (Fighter.character.scale.x > 0 ){
          Fighter.character.scale.x *=-1;
          Fighter.weapon1.trackSprite(Fighter.character, 28, -40, true);
          }

          Fighter.character.body.velocity.x = -250;
          Fighter.character.animations.play('right');
      }

      else if (controller.right.isDown && !(Fighter.m < 120 && Fighter.m != 0))
      {
          //  Move to the right

          //logic to change direction facing
          if (Fighter.character.scale.x < 0 ){
          Fighter.character.scale.x *=-1;
          Fighter.weapon1.trackSprite(Fighter.character, 28, 40, true);
          }

          Fighter.character.body.velocity.x = 250;
          Fighter.character.animations.play('right');
      }
      //else if (controller.up.isDown && Fighter.character.body.touching.down)
      else if (controller.up.isDown && Fighter.jumps <= 5 && controller.up.downDuration(80) && !(Fighter.m < 120 && Fighter.m != 0))
      {
          Fighter.character.body.velocity.y = -350;
          Fighter.jumps += 1;
      }
       else if (controller.down.isDown && Fighter.character.body.touching.down)
      {
        Fighter.character.body.velocity.x = 0;
          Fighter.character.animations.play('shield');
      }
      else if (controller.punch.isDown && controller.punch.downDuration(80) && !(Fighter.m < 120 && Fighter.m != 0))
      {
          //logic to change direction facing
          if (Fighter.character.scale.x < 0 ){
         Fighter.character.body.velocity.x = -250;
          }
          else
          {
          Fighter.character.body.velocity.x = 250;
          }

          Fighter.character.animations.play('punch');
          Fighter.weapon1.fire();
          Fighter.health += 1;


      }
      else if (controller.kick.isDown && controller.kick.downDuration(200) && !(Fighter.m < 120 && Fighter.m != 0))
      {
          //  Move to the right

          //logic to change direction facing
          if (Fighter.character.scale.x < 0 ){
         Fighter.character.body.velocity.x = -350;
          }
          else
          {
          Fighter.character.body.velocity.x = 350;
          }

          Fighter.character.animations.play('kick');
          Fighter.weapon1.fire();

          if(Fighter.character.body.touching.down)
          {
            Fighter.character.body.velocity.y = -200;
        }

      }

      else
      {
          Fighter.character.body.velocity.x = 0;
          Fighter.character.animations.play('idle');

          if(Fighter.character.body.touching.down)
          {
            Fighter.jumps = 0;
        }
      }

  },



  item: function(type, startx, starty){
    this.type = game.add.sprite(startx, starty, type);

    game.physics.arcade.enable(this.type);

    this.type.body.bounce.y = 0;//0.2;
      this.type.body.gravity.y = 400;
      this.type.body.collideWorldBounds = false;
      return this;
  },

  respawn: function(Fighter){
      console.log("Beginning of respawn");
      //this.Fighter = Fighter;
      var test = Fighter.controlnum;
      console.log(Fighter);

      if(Fighter.controlnum == 1 ){
          console.log("controlnum = 1");
          //Fighter.character.body.position.x = 200;
          Fighter.character.x = 200;
          Fighter.character.y = 300;
          Fighter.respawnSwitch = true;
          Fighter.m = 0;
      }

      else if(Fighter.controlnum == 2 ){
          console.log("controlnum = 2");
          Fighter.character.x = 600;
          Fighter.character.y = 300;
          Fighter.respawnSwitch = true;
          Fighter.m = 0;
      }

      Fighter.health = 0;
      Fighter.lives += -1;
      Fighter.character.body.velocity.x = 0;
      Fighter.character.body.velocity.y = 0;
  },

  respawnEvent: function(Fighter){
    //Respawn Switch is activated during the KO function
    if (Fighter.respawnSwitch == true){
        Fighter.m += 1;

        //Invisible moment
        if (Fighter.m < 60 && Fighter.m != 0){
          Fighter.character.body.gravity.y = 0;
          Fighter.character.visible = false;
        }
        //Book Crashing down Animation
        else if(Fighter.m >= 60 && Fighter.m < 120){
          Fighter.character.body.gravity.y = 800;
          Fighter.character.visible = true;
        }
        else{
          Fighter.character.body.gravity.y = 400;
        }

        //Makes character alpha to signify invulnerability
        if (Fighter.m <= 360){
          Fighter.character.alpha = 0.5;
        }
        else{
          Fighter.character.alpha = 1;
          Fighter.m = 0;
          Fighter.respawnSwitch = false;
        }
      }
  },

  KO:function(Fighter){
      if(Fighter.character.body.position.x < -50 || Fighter.character.body.position.x > 900){
         respawn(Fighter);
         addOnce(this.start,this);
      }
      else if(Fighter.character.body.position.y > 700 || Fighter.character.body.position.y < -100){
         respawn(Fighter);
      }
  },


 create: function() {

      //  We're going to be using physics, so enable the Arcade Physics system

      game.time.advandedTiming = true;

      //  A simple background for our game
      game.add.sprite(0, 0, 'sky');

      //  The platforms group contains the ground and the 2 ledges we can jump on
      platforms = game.add.group();

      //  We will enable physics for any object that is created in this group
      platforms.enableBody = true;

      // Here we create the ground.
      var ground = platforms.create(110, game.world.height - 30, 'ground');

      //  Scale it to fit the width of the game (the original sprite is ? in size)
      ground.scale.setTo(18, 1);

      //  This stops it from falling away when you jump on it
      ground.body.immovable = true;

      //  Now let's create two ledges
     // var ledge = platforms.create(400, 400, 'ground');
      //ledge.body.immovable = true;

      //ledge = platforms.create(-150, 250, 'ground');
      //ledge.body.immovable = true;


      //Player1 = new Fighter('dude',  0, 3, 200,400,1);
      //Player2 = new Fighter('chick', 0, 3, 600,400,2);

    Player1 =  this.Fighter('dude',  0, 3, game.world.width*0.25,game.world.height*0.5,1);
      //   Fighter: function(character,health,lives,startx,starty,controlnum)
      console.log(Player1);
    Player2 =  this.Fighter('chick', 0, 3, game.world.width*0.75,game.world.height*0.5,2);


     	bottle = this.item('bottle', 300, 200);




      healthtext1 = game.add.text(0,0, `DMG ${Player1.health}`,style);

      healthtext2 = game.add.text(650,0, `DMG ${Player2.health}`,style);

      livetext1 = game.add.text(0,30, `Lives ${Player1.lives}`,style);

      livetext2 = game.add.text(650,30, `Lives ${Player2.lives}`,style);

      //fpstext = game.add.text(400, 30, `FPS ${game.time.fps}`,style);


      /*
      weapon1 = game.add.weapon(1, 'slash');
      weapon1.bulletKillType = Phaser.Weapon.KILL_LIFESPAN;
      weapon1.bulletLifespan = 50;
      weapon1.bulletSpeed = 0;
      weapon1.fireRate = 1;
      weapon1.trackSprite(Player2.character, 28, 40, true);
      */

      // var nameLabel=game.add.text(80,80,'Playing the game',{font: '50px Arial',fill: '#ffffff'});
      // var startLabel=game.add.text(80,game.world.height-80,'Press "W" key to win',{font: '25px Arial',fill:'#ffffff'});
      // var wkey= game.input.keyboard.addKey(Phaser.Keyboard.W);
       //wkey.onDown.addOnce(this.start,this);

  },

  update: function() {
    ///////////////////////////////////////////////////////////////////////////////THis is probably the problem
    game.physics.arcade.overlap(Player1.character, this.win, this.Win, null, this);
    game.physics.arcade.overlap(Player2.character, this.win, this.Win, null, this);
////////////////////////////////////////////////////////////////////////////////////////
      //  Collide the players with the platforms and eachother
      game.physics.arcade.collide(Player1.character, platforms);
      game.physics.arcade.collide(Player2.character, platforms);
      game.physics.arcade.collide(Player1.character,Player2.character);
  	game.physics.arcade.collide(Player1.weapon1.bullets, Player2.character, this.hit);
  	game.physics.arcade.collide(Player2.weapon1.bullets, Player1.character, this.hit);
  	//overlap(object1, object2, overlapCallback, processCallback, callbackContext)
      //Enable items collisions
      game.physics.arcade.collide(bottle.type, platforms);
      game.physics.arcade.collide(Player1.character, bottle.type);
  	game.physics.arcade.collide(Player2.character, bottle.type);

     	this.updateInput(controller1,Player1,cooldown1);
     	this.updateInput(controller2,Player2,cooldown2);



       healthtext1.text = `DMG ${Player1.health}`;
       healthtext2.text = `DMG ${Player2.health}`;

       livetext1.text = `Lives ${Player1.lives}`;
       livetext2.text = `Lives ${Player2.lives}`;


      //healthtext2 = game.add.text(690,0, `Lives ${Player2.health}`,style);
      this.KO(Player1);
      this.KO(Player2);

      this.respawnEvent(Player1);
      this.respawnEvent(Player2);




  },


  start: function(){
   game.state.start('win');

  }
};
