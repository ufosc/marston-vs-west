console.log("Reached options state");
var optionsState={
  //Plan to add: fullscreen, change aspect ratio, keyboard config?,
   create: function(){
   	var nameLabel=game.add.text(80,80,'Options menu',{font: '50px Arial',fill: '#ffffff'});
   	var startLabel=game.add.text(80,game.world.height-40,'Under Construction',{font: '25px Arial',fill:'#ffffff'});
    menuButton = game.add.button(game.world.width *.5 -195,game.world.height *.5 - 100, 'menuButton');
    menuButton.onInputUp.add(this.menu,this);
    var marstonPicture = game.add.image(game.world.width * .5, game.world.height * .5 + 50, 'marstonPic');
    marstonPicture.anchor.setTo(.5,.5);
    marstonPicture.scale.setTo(.5,.5);
    fullScreenButton = game.add.button(game.world.width *.5,game.world.height *.5 - 100, 'fullScreenButton');
    fullScreenButton.onInputUp.add(this.fullScreenConfig, this);
  },
  menu: function () {
    game.state.start('menu');
  },
  fullScreenConfig: function()
  {
    console.log("Calling fullscreen function");
    this.game.scaleMode = Phaser.ScaleManager.EXACT_FIT;
  }

};
