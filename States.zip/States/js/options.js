console.log("Reached options state");
var optionsState={
   create: function(){
   	var nameLabel=game.add.text(80,80,'Marston West Game',{font: '50px Arial',fill: '#ffffff'});
   	var startLabel=game.add.text(80,game.world.height-80,'Press "W" key to start',{font: '25px Arial',fill:'#ffffff'});
    menuButton = game.add.button(game.world.width *.5 -95,game.world.height *.5 - 100, 'menuButton');
    menuButton.onInputUp.add(this.menu,this);
  },
  menu: function () {
    game.state.start('menu');
  }

};
