var game = new Phaser.Game(800, 600, Phaser.AUTO, 'gameDiv');
var player;
var weapon;
var weapon2;
var weapon3;
var weapon3y;

var weapon1;


var platforms;
var cursors;
var punchkey;
var combo = 0; //variable for punch comobo
var kickkey;
var j = 0; // temporary variable

var energyText;
var playerstate; //may be implemented later on in fighter class


var controller;
var pun;

var stars;
var score = 0;
var scoreText;

var healthtext1;
var healthtext2;

var livetext1;
var livetext2;

var style =
    {
        font: "bold 32px Arial", fill: "#fff", boundsAlignH: "left", boundsAlignV: "top"
    };


var enemyText;
var enemy;
var bottle;
var helmet;

var hitbox1;
var myPlayer;
var hitboxes;


var prevkey; //currently unused

var Player1;
var Player2;

var controller1;
var controller2;

//cooldown vars
var cooldown1;
var cooldown2;

var charactername;
var startButton;
var optionsButton;
var quitButton;
var menuButton;

var music;

game.state.add('boot',bootState);
game.state.add('options',optionsState);
game.state.add('credits',creditsState);
game.state.add('load',loadState);
game.state.add('menu',menuState);
game.state.add('play',playState);
game.state.add('win',winState);

game.state.start('boot');
