var menuState={

   create: function(){
   	var nameLabel=game.add.text(80,80,'Marston West Game',{font: '50px Arial',fill: '#ffffff'});
   	var startLabel=game.add.text(80,game.world.height-80,'Press "W" key to start',{font: '25px Arial',fill:'#ffffff'});
   	var wkey= game.input.keyboard.addKey(Phaser.Keyboard.W);
   	wkey.onDown.addOnce(this.start,this); //Keep for debugging purposes, makes launching the game quicker

    startButton = game.add.button(game.world.width *.5 -95,game.world.height *.5 - 100, 'startButton');
    startButton.onInputUp.add(this.start,this);

    optionsButton = game.add.button(game.world.width *.5 -95,game.world.height *.5, 'optionsButton');
    optionsButton.onInputUp.add(this.options,this);

    creditsButton = game.add.button(game.world.width *.5 -95,game.world.height *.5 + 100, 'creditsButton');
    creditsButton.onInputUp.add(this.credits,this);

    quitButton = game.add.button(game.world.width *.5 -95,game.world.height *.5 + 200, 'quitButton');
    quitButton.onInputUp.add(this.quit,this);

    music = game.add.audio('menuMusic');
    music.play();
   },
   start: function(){
     music.destroy();
    game.cache.removeSound('menuMusic');
    game.state.start('play');

  },
  options: function() {
    console.log("options state")
  },
  quit:function() {
    console.log("quit state");
  },
  credits: function() {
    game.state.start('credits');
  }
};
